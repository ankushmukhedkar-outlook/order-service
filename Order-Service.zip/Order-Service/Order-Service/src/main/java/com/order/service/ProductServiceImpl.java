package com.order.service;

import com.order.model.Product;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name ="product-service")
@Service
public interface ProductServiceImpl {

   @GetMapping("/products/{productId}")
   public Product getProductsById(@PathVariable Long productId);

}
