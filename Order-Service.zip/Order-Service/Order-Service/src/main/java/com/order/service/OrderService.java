package com.order.service;

import com.order.model.Order;
import com.order.model.Product;
import com.order.repository.OrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;

@Service
public class OrderService {
    @Autowired
    OrderRepository orderRepository;

    @Autowired
    ProductServiceImpl productServiceImpl;

    public Order createOrder(Order orderRequest) {
        for (Product product : orderRequest.getProducts()) {

            productServiceImpl.getProductsById(product.getProdut_id());

            if (product == null) {
                throw new RuntimeException("Product with " + product.getProdut_id() +"not found");
            }
        }

        Order newOrder = new Order();
        newOrder.setCustomerName(orderRequest.getCustomerName());
        newOrder.setProducts(orderRequest.getProducts());
        newOrder.setOrderDate(LocalDate.now());

        return orderRepository.save(newOrder);
    }
}